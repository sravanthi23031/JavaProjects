package caseStudy.abstraction;

import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        InventorySystem inventory = new InventorySystem();

        // Add products to inventory
        Product p1 = new ElectronicsProduct(101, "Laptop", 60000, 5);
        Product p2 = new ClothingProduct(102, "T-Shirt", 500, 20);
        Product p3 = new GroceryProduct(103, "Milk", 50, 50);

        inventory.adddProduct(p1);
        inventory.adddProduct(p2);
        inventory.adddProduct(p3);

        // Create customer
        Customer c1 = new Customer(1, "Sravs");

        // Customer buys products
        inventory.purchaseProduct(c1, p1, 1);
        inventory.purchaseProduct(c1, p2, 2);

        // Show cart
        c1.showCart();
        System.out.println("Total: " + c1.getTotalAmount());

        // Create order
        Order order1 = new Order(1, c1.cartItems);

        // Make payment
        Payment payment = new Payment();
        payment.makePayment(order1, 61000);  // Assuming customer pays 61000
    }
}


//Inventory has products
//Customer adds products to cart
//Stock reduces automatically
//Customer sees total
//Order is created
//Payment is made


// Purpose:

// Entry point of the program.
// Can be extended to simulate the program flow:
// Add products to inventory
// Let customer purchase
// Create order
// Make payment