package caseStudy.abstraction;

import java.util.List;

class Order
{
	int orderId;
	List<CartItem> orderItems;
	double totalAmount;
	boolean orderStatus=false;
	 Order(int orderId, List<CartItem> items) {
	        this.orderId = orderId;
	        this.orderItems = items;
	        this.totalAmount = calculateTotal();
	        this.orderStatus = false;
	    }

	    double calculateTotal() {
	        double total = 0;
	        for (CartItem item : orderItems) {
	            total += item.product.price * item.quantity;
	        }
	        return total;
	    }

	    void confirmOrder() {
	        orderStatus = true;
	        System.out.println("Order #" + orderId + " confirmed. Total: " + totalAmount);
	    }
	}

// 	Purpose:
// Represents a customer order.
// Stores the items ordered, total amount, and status.

// Key Points:
// Can be extended to store List<CartItem> instead of a string for real cart objects.
// Maintains order lifecycle with orderStatus.
// Demonstrates tracking purchase information.
