package caseStudy.abstraction;

class Payment {

    boolean makePayment(Order order, double amountPaid) {
        if (amountPaid >= order.totalAmount) {
            order.confirmOrder();
            System.out.println("Payment of " + amountPaid + " successful.");
            return true;
        } else {
            System.out.println("Payment failed. Insufficient amount.");
            return false;
        }
    }
}
//Connects Order → Payment.


// Purpose:
// Handles payment processing for orders.

// Key Points:
// Currently a placeholder; can be extended to:
// Validate payment amount
// Confirm orders
// Track payment status