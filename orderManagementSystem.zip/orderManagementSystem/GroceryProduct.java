package caseStudy.abstraction;

class GroceryProduct extends Product
{
	GroceryProduct(int productId, String productName, double price, int stockQuantity)
	{
		super(productId, productName, price, stockQuantity);
	}
}