package caseStudy.abstraction;

class ClothingProduct extends Product
{
	ClothingProduct(int productId, String productName, double price, int stockQuantity)
	{
		super(productId, productName, price, stockQuantity);
	}
}