package caseStudy.abstraction;

class CartItem
{
	Product product;
	//product is an Object for Product that can hold int productId, String productName, double price, int stockQuantity
    //int quantity)
	int quantity;
	
	CartItem(Product product,int quantity)
	{
		this.product=product;
		this.quantity=quantity;
	}
}

// Purpose:
// Represents one item in a customer’s cart, including product details and quantity.

// Key Points:
// Product product stores a reference to the actual Product object in inventory.
// quantity stores how many units of the product are in the cart.
// Demonstrates composition / HAS-A relationship: CartItem has a Product.