package caseStudy.abstraction;

abstract class Product {
	//fields
    int productId;
    String productName;
    double price;
    int stockQuantity;
   //constructor for product with all product fields
    Product(int productId, String productName, double price, int stockQuantity) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.stockQuantity = stockQuantity;
    }

    
}
}
// Purpose:
// Represents a generic product in the inventory.
// Defined as abstract because we never create a generic Product directly; instead, we create specific types like Electronics, Clothing, or Grocery.

// Key Points:
// Holds common attributes: productId, productName, price, stockQuantity.
// Provides a template for all product types.
// Demonstrates abstraction and OOP inheritance.

