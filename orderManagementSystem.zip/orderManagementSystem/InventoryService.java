package caseStudy.abstraction;

import java.util.ArrayList;
import java.util.List;

class InventorySystem
{
	//inventory manages products 
//	Keep track of available products
//	Check stock availability
//	Reduce stock when customer buys
//	Show products
//	it must store product details
	List<Product> products;
	
	
	InventorySystem()
	{
		products=new ArrayList<>();
	}
	
	
	//add product
	void adddProduct(Product product)
	{
		products.add(product);
	}
	
	
	//display
	void showProducts()
	{
		for(Product p:products)
		{
		System.out.println(p.productId);
		System.out.println(p.productName);
		System.out.println(p.price);
		System.out.println(p.stockQuantity);
		}
	}
	
	boolean isAvailable(Product product,int quantity)
	{
		return product.stockQuantity >= quantity;
	}
	
	
//	reduce stock after purchase
	void reduceStock(Product product,int quantity)
	{
		product.stockQuantity-=quantity;
	}
	
//	We need a method for purchasing a product. This will:
//		Check if the product is in stock (InventorySystem.isAvailable)
//		Add it to cart
//		Reduce stock (InventorySystem.reduceStock)
	  boolean purchaseProduct(Customer customer, Product product, int quantity) {
	        if (isAvailable(product, quantity)) {
	            customer.addToCart(product, quantity);
	            reduceStock(product, quantity);
	            System.out.println(quantity + " " + product.productName + "(s) added to cart.");
	            return true;
	        } else {
	            System.out.println("Sorry, " + product.productName + " is out of stock or insufficient quantity.");
	            return false;
	        }
	    }
}


// Purpose:
// Manages the overall inventory of products.

// Responsible for:
// Adding products to inventory (adddProduct)
// Displaying products (showProducts)
// Checking stock (isAvailable)
// Reducing stock on purchase (reduceStock)

// Key Points:
// List<Product> allows dynamic storage of products.
// Central point to handle stock validation and updates.
// Demonstrates real-world system logic for inventory management.