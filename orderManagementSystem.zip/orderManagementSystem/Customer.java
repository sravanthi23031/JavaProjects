package caseStudy.abstraction;
import java.util.ArrayList;
import java.util.List;
 class Customer{
	int customerId;
	String customerName;
//	Each CartItem object internally contains:Product product;
//	int quantity;
	
	
//	cartItems ──► [
//    CartItem1 ──► ( product, quantity ),
//    CartItem2 ──► ( product, quantity ),
//    CartItem3 ──► ( product, quantity )
//]

    List<CartItem> cartItems;
    
    
    
    Customer(int customerId,String customerName)
    {
    	this.customerId=customerId;
    	this.customerName=customerName;
    	this.cartItems=new ArrayList<>();
    }
    
    
    void addToCart(Product product,int quantity)
    {
    	cartItems.add(new CartItem(product,quantity));
    }
    
    void showCart() {
		System.out.println("Cart of " + customerId + ":");
        for (CartItem item : cartItems) {
            System.out.println("Product Names :"+item.product.productName);
            System.out.println("No of Items: "+item.quantity);
            System.out.println("Price of Items: "+item.product.price);
        }
    }
    
    double getTotalAmount() {
    	double total = 0;
    	  for (CartItem item : cartItems) {
              total += item.product.price * item.quantity;
    }
    	  return total;
    }
 }


//  Purpose:
// Represents a customer of the system.
// Stores a list of CartItems for the shopping cart.

// Key Points:
// List<CartItem> cartItems allows dynamic storage of multiple items in the cart.
// Can be extended to include customer name, address, or purchase history.
// Demonstrates composition and use of Java collections.