package caseStudy.abstraction;

class ElectronicsProduct extends Product
{
	ElectronicsProduct(int productId, String productName, double price, int stockQuantity)
	{
		super(productId, productName, price, stockQuantity);
	}
}

// Purpose:
// Represent specific categories of products.
// Extend Product class and inherit its attributes.

// Key Points:
// Each class allows instantiation of specific product types.
// Can be easily extended to add category-specific behavior in the future.
// Demonstrates inheritance in OOP.